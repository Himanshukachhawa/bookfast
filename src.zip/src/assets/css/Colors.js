export const theme_bg = "#cc0013";
export const theme_fg = "#cc0013";
export const theme_bg_two = "#94999c";
export const theme_fg_two = "#52595f";
export const theme_bg_three = "#ffffff";
export const theme_fg_three = "#ffffff";
export const theme_fg_four = "#808080";
export const theme_fg_five = "#373737";

export const star_rating = "#FF9529";
export const green = "#008000";
export const red = "#FF0000";
export const promo_color = "#4dad4a";
